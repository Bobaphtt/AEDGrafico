import java.awt.*;
import java.util.Random;

public class Desenho extends Canvas {
    private int nivelMax;
    private int tamanhoyjanela;
    private int tamanhoxjanela;
    private Random r = new Random();
    int aux;
    Desenho(int x, int y){
    super();
    tamanhoxjanela = x;
    tamanhoyjanela = y;
    //this.setBackground(Color.BLUE);
    }

    public void setNivelMax(int nivelMax) {
        this.nivelMax = nivelMax;
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        int[] x = {10, this.tamanhoxjanela/2, this.tamanhoxjanela-10};
        int[] y = {this.tamanhoyjanela-50, 10, this.tamanhoyjanela-50};
        g.setColor(Color.BLUE);
        this.aux = r.nextInt(3);
        int angulo = r.nextInt(0,35);

            arvoreFractal((Graphics2D) g,this.tamanhoxjanela/2, this.tamanhoyjanela-30, 1,angulo,230);

    }
    private int probabilidade(){
        int n;


        return 1000;
    }
    public void arvoreFractal(Graphics2D g, double x, double y, int nivel, int angulo,int tamanho){
        if(nivel<nivelMax){
            double nx = x - tamanho * Math.sin(Math.toRadians(angulo));
            double ny = y - tamanho * Math.cos(Math.toRadians(angulo));
            //SET STROKE
            // marrom(100, 50,51)
            // verde(0, 150, 50)
            g.setStroke(new BasicStroke((float) (12/Math.log(nivel*nivel +1))));
            g.setColor(new Color(100 - nivel*(100/nivelMax), 50+nivel*(100/nivelMax), 50));
            g.drawLine((int) x, (int) y, (int) nx, (int) ny);
            arvoreFractal(g,nx,ny,nivel+1,angulo+(int)r.nextDouble(30,45),(int)(tamanho/r.nextDouble(1,2)));
            arvoreFractal(g,nx,ny,nivel+1,angulo-(int)r.nextDouble(30,60),(int)(tamanho/r.nextDouble(0.98,2)));
            //Thread.currentThread().wait(200);
        }


        else if (nivel==nivelMax&&r.nextInt((int)Math.pow(2,this.nivelMax))<nivelMax*3*Math.log10(Math.pow(2,this.nivelMax))) {
            int quantidade = r.nextInt(4,8); // Número de pétalas
            int tamanhopetala = 6; // Tamanho das pétalas
                double variancia = r.nextDouble(0.5,1);
                g.setColor(new Color((int)((75*aux)*variancia),10,(int)((255-75*aux)*variancia)));
                for (int i = 0; i < quantidade; i++) {

                    double angulopetala = 2 * Math.PI * i / quantidade;
                    int xOffset = (int) (tamanhopetala * Math.cos(angulopetala));
                    int yOffset = (int) (tamanhopetala * Math.sin(angulopetala));


                    g.fillOval((int)(x + xOffset - tamanhopetala / 2), (int)(y + yOffset - tamanhopetala / 2), tamanhopetala, tamanhopetala);
                }
                g.setColor(Color.YELLOW);
                g.fillOval((int)(x - 1.2*tamanhopetala / 2), (int)(y - 1.2*tamanhopetala / 2), (int)(1.2*tamanhopetala), (int)(1.2*tamanhopetala));

        }


    }
}
